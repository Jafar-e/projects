const math = require('./math.js');

console.log(math.add(545545,845454));
console.log(math.subtract(151654,65421));