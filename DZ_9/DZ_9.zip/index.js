let x = "Some test text";
console.log(y);